const INTEGRATED_KEYS = {
  groq: "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",
  google: "AQ.Ab8RN6J8kyoZrlEs6H9V2yKX1LQNQkw3pejLZido-cvHIP3qqg",
  mistral: "teXtQv26nrqSx5X23jZGAB8fXgyvnTUH",
  openrouter: "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"
};
export type ProviderId = 'mistral' | 'google' | 'groq' | 'openrouter';

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface AIResponse {
  text: string;
  tokensUsed: number | null;
}

interface Provider {
  id: ProviderId;
  label: string;
  keyUrl: string;
  defaultModel: string;
  buildRequest(cfg: { apiKey: string; model: string; messages: ChatMessage[]; systemPrompt: string }): { url: string; init: RequestInit };
  parseResponse(json: unknown): AIResponse;
}

function oaiMessages(systemPrompt: string, messages: ChatMessage[]) {
  const out: { role: string; content: string }[] = [];
  if (systemPrompt) out.push({ role: 'system', content: systemPrompt });
  for (const m of messages) out.push({ role: m.role, content: m.content });
  return out;
}

const mistral: Provider = {
  id: 'mistral', label: 'Mistral // Codestral',
  keyUrl: 'https://console.mistral.ai/api-keys', defaultModel: 'codestral-latest',
  buildRequest({ apiKey, model, messages, systemPrompt }) {
    return { url: 'https://api.mistral.ai/v1/chat/completions', init: { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` }, body: JSON.stringify({ model: model || 'codestral-latest', messages: oaiMessages(systemPrompt, messages), temperature: 0.15 }) } }
  },
  parseResponse(json: any): AIResponse { return { text: json?.choices?.[0]?.message?.content ?? '', tokensUsed: json?.usage?.total_tokens ?? null } }
}

const google: Provider = {
  id: 'google', label: 'Google AI // Gemini Flash',
  keyUrl: 'https://aistudio.google.com/app/apikey', defaultModel: 'gemini-2.0-flash',
  buildRequest({ apiKey, model, messages, systemPrompt }) {
    const m = model || 'gemini-2.0-flash';
    const contents = messages.map((msg) => ({ role: msg.role === 'assistant' ? 'model' : 'user', parts: [{ text: msg.content }] }));
    const body: Record<string, unknown> = { contents };
    if (systemPrompt) body.systemInstruction = { parts: [{ text: systemPrompt }] };
    return { url: `https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${apiKey}`, init: { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } }
  },
  parseResponse(json: any): AIResponse { return { text: json?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join('') ?? '', tokensUsed: json?.usageMetadata?.totalTokenCount ?? null } }
}

const groq: Provider = {
  id: 'groq', label: 'Groq // Llama-3.3-70B',
  keyUrl: 'https://console.groq.com/keys', defaultModel: 'llama-3.3-70b-versatile',
  buildRequest({ apiKey, model, messages, systemPrompt }) {
    return { url: 'https://api.groq.com/openai/v1/chat/completions', init: { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` }, body: JSON.stringify({ model: model || 'llama-3.3-70b-versatile', messages: oaiMessages(systemPrompt, messages), temperature: 0.25 }) } }
  },
  parseResponse(json: any): AIResponse { return { text: json?.choices?.[0]?.message?.content ?? '', tokensUsed: json?.usage?.total_tokens ?? null } }
}

const openrouter: Provider = {
  id: 'openrouter', label: 'OpenRouter // Qwen-Coder',
  keyUrl: 'https://openrouter.ai/keys', defaultModel: 'qwen/qwen-2.5-coder-32b-instruct:free',
  buildRequest({ apiKey, model, messages, systemPrompt }) {
    return { url: 'https://openrouter.ai/api/v1/chat/completions', init: { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}`, 'HTTP-Referer': typeof window !== 'undefined' ? window.location.origin : '', 'X-Title': 'ALUKAZE AI' }, body: JSON.stringify({ model: model || 'qwen/qwen-2.5-coder-32b-instruct:free', messages: oaiMessages(systemPrompt, messages) }) } }
  },
  parseResponse(json: any): AIResponse { return { text: json?.choices?.[0]?.message?.content ?? '', tokensUsed: json?.usage?.total_tokens ?? null } }
}

export const PROVIDERS: Record<ProviderId, Provider> = { mistral, google, groq, openrouter };

const CODING_SYSTEM_PROMPT = `You are ALUKAZE AI — an architectural cognitive engine specialising in code. Respond with precise, production-ready code. Use markdown code fences with the language name. Be direct. No filler.`;

export async function sendToAI(providerId: ProviderId, apiKey: string, model: string, messages: ChatMessage[]): Promise<AIResponse> {
  const provider = PROVIDERS[providerId];
  const activeKey = INTEGRATED_KEYS[providerId] && !INTEGRATED_KEYS[providerId].includes("YOUR_") 
    ? INTEGRATED_KEYS[providerId] 
    : apiKey;

  if (!activeKey.trim()) throw new Error(`// NO KEY — configure ${provider.label} in SETTINGS or hardcode it in ai.ts`);
  const { url, init } = provider.buildRequest({ apiKey: activeKey.trim(), model: model || provider.defaultModel, messages, systemPrompt: CODING_SYSTEM_PROMPT });
  let res: Response;
  try { res = await fetch(url, init) } catch (err: any) { throw new Error(`// NETWORK FAULT — ${provider.label} unreachable.\n${err.message}`) }
  const json = await res.json().catch(() => null);
  if (!res.ok) { const detail = (json as any)?.error?.message || res.statusText; throw new Error(`// API FAULT ${res.status} — ${provider.label}: ${detail}`) }
  return provider.parseResponse(json);
}

export interface AppSettings { activeProvider: ProviderId; apiKeys: Record<ProviderId, string>; models: Record<ProviderId, string>; splineUrl: string }
export interface TokenTally { mistral: number; google: number; groq: number; openrouter: number }

const DEFAULTS: AppSettings = { activeProvider: 'groq', apiKeys: { mistral: '', google: '', groq: '', openrouter: '' }, models: { mistral: '', google: '', groq: '', openrouter: '' }, splineUrl: '' };

export function loadSettings(): AppSettings {
  try { const raw = localStorage.getItem('alukaze:settings'); if (!raw) return structuredClone(DEFAULTS); const p = JSON.parse(raw); return { ...structuredClone(DEFAULTS), ...p, apiKeys: { ...DEFAULTS.apiKeys, ...(p.apiKeys ?? {}) }, models: { ...DEFAULTS.models, ...(p.models ?? {}) } } } catch { return structuredClone(DEFAULTS) }
}
export function saveSettings(s: AppSettings): void { localStorage.setItem('alukaze:settings', JSON.stringify(s)) }
export function loadTally(): TokenTally {
  try { const raw = localStorage.getItem('alukaze:tokens'); return raw ? JSON.parse(raw) : { mistral: 0, google: 0, groq: 0, openrouter: 0 } } catch { return { mistral: 0, google: 0, groq: 0, openrouter: 0 } }
}
export function addTally(pid: ProviderId, n: number | null): TokenTally {
  const t = loadTally(); if (n) t[pid] = (t[pid] || 0) + n; localStorage.setItem('alukaze:tokens', JSON.stringify(t)); return t
}

export async function generateChatResponse(
  provider: ProviderId,
  model: string,
  messages: ChatMessage[],
  systemPrompt: string = "You are ALUKAZE AI, an expert coding assistant.",
  localApiKey?: string
): Promise<AIResponse> {
  const activeKey = INTEGRATED_KEYS[provider] && !INTEGRATED_KEYS[provider].includes("YOUR_") 
    ? INTEGRATED_KEYS[provider] 
    : (localStorage.getItem(`${provider.toUpperCase()}_API_KEY`) || localApiKey);

  if (!activeKey) {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, model, messages, systemPrompt }),
    });

    if (!response.ok) {
      throw new Error(`Server returned status ${response.status}`);
    }

    const data = await response.json();

    if (provider === 'google') {
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
      return { text, tokensUsed: null };
    } else {
      const text = data.choices?.[0]?.message?.content || '';
      const tokensUsed = data.usage?.total_tokens || null;
      return { text, tokensUsed };
    }
  }

  let url = '';
  let headers: Record<string, string> = { 'Content-Type': 'application/json' };
  let bodyData: any = {};

  const formattedMessages = systemPrompt
    ? [{ role: 'system', content: systemPrompt }, ...messages]
    : messages;

  if (provider === 'groq') {
    url = 'https://api.groq.com/openai/v1/chat/completions';
    headers['Authorization'] = `Bearer ${activeKey}`;
    bodyData = { model, messages: formattedMessages };
  } else if (provider === 'mistral') {
    url = 'https://api.mistral.ai/v1/chat/completions';
    headers['Authorization'] = `Bearer ${activeKey}`;
    bodyData = { model, messages: formattedMessages };
  } else if (provider === 'openrouter') {
    url = 'https://openrouter.ai/api/v1/chat/completions';
    headers['Authorization'] = `Bearer ${activeKey}`;
    bodyData = { model, messages: formattedMessages };
  } else if (provider === 'google') {
    url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${activeKey}`;
    bodyData = {
      contents: messages.map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      })),
    };
  }

  const response = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(bodyData),
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.statusText}`);
  }

  const data = await response.json();
  if (provider === 'google') {
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    return { text, tokensUsed: null };
  } else {
    const text = data.choices?.[0]?.message?.content || '';
    const tokensUsed = data.usage?.total_tokens || null;
    return { text, tokensUsed };
  }
}