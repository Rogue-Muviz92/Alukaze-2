import React, { useState, useRef, useEffect, useCallback, Suspense, lazy, type KeyboardEvent } from 'react'
import { sendToAI, loadSettings, saveSettings, loadTally, addTally, PROVIDERS, type AppSettings, type ChatMessage, type ProviderId, type TokenTally } from './lib/ai'

const Spline = lazy(() => import('@splinetool/react-spline'))

interface Message { id: string; role: 'user' | 'assistant' | 'system'; content: string; ts: number; error?: boolean; typing?: boolean }

function AlukazeLogo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 2 L30 16 L16 30 L2 16 Z" stroke="#FAFF00" strokeWidth="1.2" fill="none" strokeLinejoin="round" />
      <path d="M16 8 L22 22 M16 8 L10 22 M12 18 L20 18" stroke="#FAFF00" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="16" cy="2" r="1.2" fill="#FAFF00" />
      <circle cx="30" cy="16" r="1.2" fill="#FAFF00" />
      <circle cx="16" cy="30" r="1.2" fill="#FAFF00" />
      <circle cx="2" cy="16" r="1.2" fill="#FAFF00" />
    </svg>
  )
}

function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const [copied, setCopied] = useState(false)
  function handleCopy() { navigator.clipboard.writeText(code).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1800) }) }
  return (
    <div className="code-block my-3">
      <div className="code-block-header">
        <span style={{ color: '#FAFF00', fontSize: '0.7rem', letterSpacing: '0.1em' }}>// {lang || 'CODE'}</span>
        <button onClick={handleCopy} className="btn-ghost text-xs px-2 py-0.5 rounded" style={{ fontSize: '0.68rem' }}>{copied ? '// COPIED' : '// COPY'}</button>
      </div>
      <pre style={{ margin: 0, padding: '12px 16px', overflowX: 'auto', color: '#e0e0e0', fontSize: '0.78rem', lineHeight: '1.65' }}>
        <code>{code}</code>
      </pre>
    </div>
  )
}

function InlineText({ text }: { text: string }) {
  const inlineRx = /`([^`]+)`/g
  const parts: React.ReactNode[] = []
  let last = 0; let match: RegExpExecArray | null
  while ((match = inlineRx.exec(text)) !== null) {
    if (match.index > last) parts.push(text.slice(last, match.index))
    parts.push(<code key={match.index} style={{ background: '#111', border: '1px solid #1c1c1c', borderRadius: 3, padding: '1px 5px', color: '#FAFF00', fontSize: '0.8em' }}>{match[1]}</code>)
    last = match.index + match[0].length
  }
  if (last < text.length) parts.push(text.slice(last))
  return <span style={{ whiteSpace: 'pre-wrap', lineHeight: 1.7 }}>{parts}</span>
}

function RenderContent({ content }: { content: string }) {
  const codeBlockRx = /```(\w*)\n?([\s\S]*?)```/g
  const parts: React.ReactNode[] = []
  let last = 0; let match: RegExpExecArray | null
  while ((match = codeBlockRx.exec(content)) !== null) {
    if (match.index > last) parts.push(<InlineText key={`t-${last}`} text={content.slice(last, match.index)} />)
    parts.push(<CodeBlock key={`c-${match.index}`} lang={match[1]} code={match[2].trimEnd()} />)
    last = match.index + match[0].length
  }
  if (last < content.length) parts.push(<InlineText key="t-end" text={content.slice(last)} />)
  return <>{parts}</>
}

function MessageRow({ msg }: { msg: Message }) {
  if (msg.role === 'system') return <div className="msg-enter msg-system py-1">{msg.content}</div>
  const ts = new Date(msg.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  return (
    <div className={`msg-enter py-2 ${msg.role === 'user' ? 'msg-user' : 'msg-ai'}`}>
      <div style={{ fontSize: '0.65rem', letterSpacing: '0.12em', marginBottom: 4, color: msg.role === 'user' ? '#FAFF00' : '#444', textTransform: 'uppercase' }}>
        {msg.role === 'user' ? '// USER_DIRECTIVE' : '// ALUKAZE_RESPONSE'} <span style={{ color: '#333', marginLeft: 8 }}>{ts}</span>
      </div>
      {msg.error ? <div style={{ color: '#ff6666', whiteSpace: 'pre-wrap', fontSize: '0.82rem' }}>{msg.content}</div>
        : msg.typing ? <div className="cursor" style={{ fontSize: '0.82rem', color: '#888' }}>PROCESSING</div>
        : <div style={{ fontSize: '0.82rem' }}><RenderContent content={msg.content} /></div>}
    </div>
  )
}

function SettingsPanel({ open, onClose, settings, onChange, tally }: { open: boolean; onClose: () => void; settings: AppSettings; onChange: (s: AppSettings) => void; tally: TokenTally }) {
  function setKey(pid: ProviderId, val: string) { onChange({ ...settings, apiKeys: { ...settings.apiKeys, [pid]: val } }) }
  function setModel(pid: ProviderId, val: string) { onChange({ ...settings, models: { ...settings.models, [pid]: val } }) }
  return (
    <>
      {open && <div className="fixed inset-0 z-40" style={{ background: 'rgba(0,0,0,0.6)' }} onClick={onClose} />}
      <div className={`panel-slide fixed top-0 right-0 h-full z-50 flex flex-col ${open ? 'open' : ''}`} style={{ width: 'min(420px, 100vw)', background: '#060606', borderLeft: '1px solid #1c1c1c' }}>
        <div style={{ padding: '18px 20px', borderBottom: '1px solid #1c1c1c', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ color: '#FAFF00', fontSize: '0.75rem', letterSpacing: '0.14em' }}>// SYSTEM_CONFIG</span>
          <button className="btn-ghost text-xs px-2 py-1 rounded" onClick={onClose}>CLOSE ✕</button>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '20px' }}>
          <div style={{ marginBottom: 24 }}>
            <div className="msg-system mb-2">// ACTIVE_ENGINE</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {(Object.keys(PROVIDERS) as ProviderId[]).map((pid) => (
                <button key={pid} onClick={() => onChange({ ...settings, activeProvider: pid })}
                  style={{ padding: '8px 12px', borderRadius: 4, fontSize: '0.7rem', letterSpacing: '0.08em', border: settings.activeProvider === pid ? '1px solid #FAFF00' : '1px solid #1c1c1c', background: settings.activeProvider === pid ? 'rgba(250,255,0,0.08)' : 'transparent', color: settings.activeProvider === pid ? '#FAFF00' : '#555', cursor: 'pointer', fontFamily: 'JetBrains Mono, monospace', textAlign: 'left', transition: 'all 0.15s' }}>
                  {PROVIDERS[pid].label}
                </button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom: 24 }}>
            <div className="msg-system mb-2">// 3D_ENGINE_URL</div>
            <input type="text" value={settings.splineUrl} onChange={(e) => onChange({ ...settings, splineUrl: e.target.value })} placeholder="https://prod.spline.design/..." className="terminal-input w-full rounded px-3 py-2" style={{ fontSize: '0.72rem' }} />
            <div style={{ fontSize: '0.65rem', color: '#333', marginTop: 4 }}>Leave blank for procedural background. Get a free scene at spline.design</div>
          </div>
          {(Object.keys(PROVIDERS) as ProviderId[]).map((pid) => (
            <div key={pid} style={{ marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <span className="msg-system">// {PROVIDERS[pid].label.toUpperCase()}</span>
                <a href={PROVIDERS[pid].keyUrl} target="_blank" rel="noopener noreferrer" style={{ fontSize: '0.65rem', color: '#FAFF00', textDecoration: 'none' }}>GET FREE KEY →</a>
              </div>
              <input type="password" value={settings.apiKeys[pid]} onChange={(e) => setKey(pid, e.target.value)} placeholder={`${pid.toUpperCase()}_API_KEY`} className="terminal-input w-full rounded px-3 py-2 mb-1" style={{ fontSize: '0.72rem' }} />
              <input type="text" value={settings.models[pid]} onChange={(e) => setModel(pid, e.target.value)} placeholder={`Model override (default: ${PROVIDERS[pid].defaultModel})`} className="terminal-input w-full rounded px-3 py-2" style={{ fontSize: '0.72rem' }} />
            </div>
          ))}
          <div style={{ marginTop: 24, borderTop: '1px solid #1c1c1c', paddingTop: 20 }}>
            <div className="msg-system mb-3">// SESSION_TOKEN_TALLY</div>
            {(Object.keys(PROVIDERS) as ProviderId[]).map((pid) => (
              <div key={pid} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', padding: '4px 0', borderBottom: '1px solid #0d0d0d', color: tally[pid] > 0 ? '#f0f0f0' : '#333' }}>
                <span>{PROVIDERS[pid].label}</span>
                <span style={{ color: tally[pid] > 0 ? '#FAFF00' : '#333' }}>{tally[pid].toLocaleString()} tokens</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{ padding: '16px 20px', borderTop: '1px solid #1c1c1c' }}>
          <button className="btn-pulse w-full py-2 rounded text-sm tracking-widest" onClick={onClose}>// SAVE &amp; CLOSE</button>
        </div>
      </div>
    </>
  )
}

function Background({ url }: { url: string }) {
  if (!url.trim()) return (
    <div className="spline-fallback">
      <div className="grid-overlay" />
      <div className="scanline-sweep" />
    </div>
  )
  return (
    <div className="spline-container">
      <div className="grid-overlay" />
      <div className="scanline-sweep" />
      <Suspense fallback={<div className="spline-fallback" />}>
        <Spline scene={url} />
      </Suspense>
    </div>
  )
}const BOOT: Message[] = [
  { id: 'b0', role: 'system', content: '// ─────────────────────────────────────────────────────', ts: Date.now() },
  { id: 'b1', role: 'system', content: '// ALUKAZE AI // SERIES 01 // ARCHITECTURAL COGNITIVE ENGINE', ts: Date.now() },
  { id: 'b2', role: 'system', content: '// RUNTIME: NOMINAL — AWAITING CLIENT DIRECTIVE', ts: Date.now() },
  { id: 'b3', role: 'system', content: '// ─────────────────────────────────────────────────────', ts: Date.now() },
]

export default function App() {
  const [messages, setMessages] = useState<Message[]>(BOOT)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [settings, setSettings] = useState<AppSettings>(loadSettings)
  const [tally, setTally] = useState<TokenTally>(loadTally)
  const bottomRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => { saveSettings(settings) }, [settings])
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const buildHistory = useCallback((): ChatMessage[] => {
    return messages.filter((m) => m.role === 'user' || (m.role === 'assistant' && !m.typing && !m.error)).slice(-12).map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }))
  }, [messages])

  async function submit() {
    const text = input.trim()
    if (!text || loading) return
    const userMsg: Message = { id: crypto.randomUUID(), role: 'user', content: text, ts: Date.now() }
    const placeholder: Message = { id: crypto.randomUUID(), role: 'assistant', content: '', ts: Date.now(), typing: true }
    setMessages((prev) => [...prev, userMsg, placeholder])
    setInput('')
    setLoading(true)
    const history = buildHistory()
    history.push({ role: 'user', content: text })
    try {
      const { activeProvider, apiKeys, models } = settings
      const result = await sendToAI(activeProvider, apiKeys[activeProvider], models[activeProvider] || '', history)
      setTally(addTally(activeProvider, result.tokensUsed))
      setMessages((prev) => prev.map((m) => m.id === placeholder.id ? { ...m, content: result.text, typing: false } : m))
    } catch (err: any) {
      setMessages((prev) => prev.map((m) => m.id === placeholder.id ? { ...m, content: err.message, typing: false, error: true } : m))
    } finally {
      setLoading(false)
      textareaRef.current?.focus()
    }
  }

  function handleKey(e: KeyboardEvent<HTMLTextAreaElement>) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit() } }
  function inject(snippet: string) { setInput((prev) => prev ? `${prev}\n\n${snippet}` : snippet); textareaRef.current?.focus() }

  return (
    <div className="relative flex flex-col" style={{ height: '100dvh', overflow: 'hidden', background: '#000' }}>
      <Background url={settings.splineUrl} />
      <div className="relative z-10 flex flex-col h-full">
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px', height: 52, borderBottom: '1px solid #1c1c1c', background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(12px)', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <AlukazeLogo size={26} />
            <div>
              <div style={{ fontSize: '0.78rem', fontWeight: 600, letterSpacing: '0.16em', color: '#f0f0f0', lineHeight: 1 }}>ALUKAZE</div>
              <div style={{ fontSize: '0.58rem', color: '#444', letterSpacing: '0.1em', lineHeight: 1.4 }}>// SERIES 01</div>
            </div>
          </div>
          <div style={{ fontSize: '0.65rem', letterSpacing: '0.1em', color: '#FAFF00', border: '1px solid rgba(250,255,0,0.2)', padding: '3px 10px', borderRadius: 2, background: 'rgba(250,255,0,0.05)' }}>
            {PROVIDERS[settings.activeProvider].label}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ fontSize: '0.65rem', color: '#333', letterSpacing: '0.08em' }}>≈{tally[settings.activeProvider].toLocaleString()} <span style={{ color: '#1c1c1c' }}>TKN</span></div>
            <button className="btn-ghost px-3 py-1 rounded text-xs tracking-widest" onClick={() => setSettingsOpen(true)}>⚙ CONFIG</button>
          </div>
        </header>

        <main style={{ flex: 1, overflowY: 'auto', padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {messages.map((m) => <MessageRow key={m.id} msg={m} />)}
          <div ref={bottomRef} />
        </main>

        <footer style={{ flexShrink: 0, borderTop: '1px solid #1c1c1c', background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(12px)', padding: '12px 20px 16px' }}>
          <div style={{ display: 'flex', gap: 6, marginBottom: 10, flexWrap: 'wrap' }}>
            {[
              { label: '// UNIT TESTS', snippet: 'Write comprehensive unit tests for the following code:' },
              { label: '// BOILERPLATE', snippet: 'Generate a production-ready boilerplate for:' },
              { label: '// DEBUG MODE', snippet: 'Debug this error. Identify the exact breaking line and explain the fix:\n\nERROR LOG:\n\nCODE:' },
              { label: '// EXPLAIN', snippet: 'Explain this code in architectural terms:' },
              { label: '// REFACTOR', snippet: 'Refactor this code for performance and readability:' },
            ].map(({ label, snippet }) => (
              <button key={label} className="btn-ghost px-2 py-1 rounded" style={{ fontSize: '0.62rem', letterSpacing: '0.08em' }} onClick={() => inject(snippet)}>{label}</button>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <span style={{ position: 'absolute', top: 10, left: 12, fontSize: '0.7rem', color: '#FAFF00', pointerEvents: 'none', userSelect: 'none' }}>&gt;_</span>
              <textarea ref={textareaRef} rows={3} value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={handleKey} placeholder="// ENTER CLIENT DIRECTIVE — Shift+Enter for new line" disabled={loading} className="terminal-input w-full rounded" style={{ paddingLeft: 40, paddingRight: 12, paddingTop: 10, paddingBottom: 10, maxHeight: 200, opacity: loading ? 0.5 : 1 }} />
            </div>
            <button className="btn-pulse rounded" disabled={loading || !input.trim()} onClick={submit} style={{ padding: '10px 18px', fontSize: '0.72rem', letterSpacing: '0.12em', opacity: loading || !input.trim() ? 0.4 : 1, cursor: loading || !input.trim() ? 'not-allowed' : 'pointer', whiteSpace: 'nowrap' }}>
              {loading ? '// PROC…' : '// SEND'}
            </button>
          </div>
          <div style={{ marginTop: 8, fontSize: '0.62rem', color: '#2a2a2a', letterSpacing: '0.08em', display: 'flex', justifyContent: 'space-between' }}>
            <span>// ALUKAZE AI · SERIES 01 · ARCHITECTURAL COGNITIVE ENGINE</span>
            <span style={{ color: loading ? '#FAFF00' : '#2a2a2a' }}>{loading ? '// STREAM ACTIVE' : '// IDLE'}</span>
          </div>
        </footer>
      </div>

      <SettingsPanel open={settingsOpen} onClose={() => setSettingsOpen(false)} settings={settings} onChange={setSettings} tally={tally} />
    </div>
  )
}