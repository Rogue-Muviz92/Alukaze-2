/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        mono: ['"JetBrains Mono"', '"Fira Code"', 'monospace'],
      },
      colors: {
        void:    '#000000',
        shell:   '#060606',
        surface: '#0d0d0d',
        panel:   '#111111',
        rim:     '#1c1c1c',
        fence:   '#2a2a2a',
        ash:     '#444444',
        smoke:   '#666666',
        haze:    '#888888',
        ghost:   '#bbbbbb',
        snow:    '#f0f0f0',
        pulse:   '#FAFF00',
        'pulse-dim': 'rgba(250,255,0,0.12)',
        'pulse-rim': 'rgba(250,255,0,0.30)',
      },
      keyframes: {
        blink: {
          '0%,100%': { opacity: '1' },
          '50%': { opacity: '0' },
        },
        scanline: {
          '0%':   { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        fadein: {
          '0%':   { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        blink:    'blink 1s step-end infinite',
        scanline: 'scanline 6s linear infinite',
        fadein:   'fadein 0.25s ease-out',
      },
    },
  },
  plugins: [],
}