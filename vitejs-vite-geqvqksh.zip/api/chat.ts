import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { provider, model, messages, systemPrompt } = req.body;

  try {
    let url = '';
    let apiKey = '';
    let bodyData: any = {};

    const formattedMessages = systemPrompt 
      ? [{ role: 'system', content: systemPrompt }, ...messages]
      : messages;

    if (provider === 'groq') {
      url = 'https://api.groq.com/openai/v1/chat/completions';
      apiKey = process.env.GROQ_API_KEY || '';
      bodyData = { model: model || 'llama-3.3-70b-specdec', messages: formattedMessages };
    } else if (provider === 'mistral') {
      url = 'https://api.mistral.ai/v1/chat/completions';
      apiKey = process.env.MISTRAL_API_KEY || '';
      bodyData = { model: model || 'mistral-large-latest', messages: formattedMessages };
    } else if (provider === 'openrouter') {
      url = 'https://openrouter.ai/api/v1/chat/completions';
      apiKey = process.env.OPENROUTER_API_KEY || '';
      bodyData = { model: model || 'google/gemini-2.5-flash', messages: formattedMessages };
    } else if (provider === 'google') {
      url = `https://generativelanguage.googleapis.com/v1beta/models/${model || 'gemini-1.5-flash'}:generateContent?key=${process.env.GOOGLE_API_KEY}`;
      bodyData = {
        contents: messages.map((m: any) => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }]
        }))
      };
    } else {
      return res.status(400).json({ error: 'Unsupported provider' });
    }

    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;

    const aiResponse = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(bodyData),
    });

    const data = await aiResponse.json();
    return res.status(200).json(data);
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Backend proxy connection failed' });
  }
}